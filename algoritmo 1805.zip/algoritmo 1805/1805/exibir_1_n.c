//Ler um inteiro N positivo (>0) - validar, usando do-while
//Exibir os inteiros de 1 até n - usando for
#include <stdio.h>
#include <stdlib.h>

int main(){
    int n;
    do{
        printf("Digite um número inteiro positivo:\n--> ");
        scanf("%d", &n);
    }
    while(n <= 0);
    for(int i = 0; i <= n; i++){
        printf("%d ", i);
    }
    
    return 0;
}