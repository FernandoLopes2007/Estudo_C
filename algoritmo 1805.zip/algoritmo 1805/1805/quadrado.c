#include <stdio.h>
int main(){
    int n, linha, coluna;
    do
    {
        printf("Digite o lado do quadrado:\n--> ");
        scanf("%d", &n);
    } while (n <=0);
    printf("Quadrado:\n");
    for(linha=1; linha <=n; linha++){
        for(coluna=1; coluna <=n; coluna ++){
            printf(" * ");
        }
        printf("\n");
    }
    printf("Triangulo:\n");
    for(linha=1; linha <=n; linha++){
        for(coluna=1; coluna <=linha; coluna ++){
            printf(" * ");
        }
        printf("\n");
    }
    printf("Triangulo Invertido:\n");
    for(linha=1; linha <=n; linha++){
        for(coluna=1; coluna <=n-linha+1; coluna ++){
            printf(" * ");
        }
        printf("\n");
    }
    printf("Caixa:\n");
    //Primeira linha
    for(coluna=1; coluna <=n; coluna++){
        printf(" * ");
    }
    printf("\n");
    //linhas do meio
    for(linha=1; linha <=n-2; linha++){
            //1a coluna
            printf(" * ");
            //colunas do meio
            for(coluna=1; coluna<=n-2; coluna ++){
                printf("   ");
            }
            //ultima coluna
            printf(" *  \n");
        }
    //Ultima linha
    for(coluna=1; coluna <=n; coluna++){
        printf(" * ");
    }
    
    return 0;
}