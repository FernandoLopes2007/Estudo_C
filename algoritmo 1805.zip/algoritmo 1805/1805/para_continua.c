//teste para mostrar o funcionamento do comando do_while
#include <stdio.h>
#include <stdlib.h>
int main(){
    char escolha;
    do{
        printf("Digite (c) para continuar ou outra letra para parar: ");
        scanf(" %c", &escolha);
    } while(escolha == 'c' || escolha == 'C');

    return 0;
}