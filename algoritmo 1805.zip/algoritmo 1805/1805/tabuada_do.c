//Ler um inteiro n, calcular e mostrar sua tabuada
// Usando o comando do - while
#include <stdio.h>
#include <stdlib.h>

int main(){
    int n, i = 0;
    printf("Digite um valor:\n--> ");
    scanf("%d", &n);
    printf("--- Tabuada do %d ---", n);
    do{
        printf("%d X %2d = %3d\n", n, i, n*i);
        i++;
    }
    while(i <= 10);
    return 0;
}